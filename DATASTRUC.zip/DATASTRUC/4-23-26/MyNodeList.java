public class MyNodeList 
{
   MyNode head;
   MyNode tail;
   int count;
   
   public MyNodeList()
   {
      head = null;
      tail = null;
      count = 0;
   }
   
   public boolean isEmpty()
   {
      if(head == null && tail == null)
         return true;
      else
         return false;
   }
   
   public boolean isFull()
   {
      return false;
   }
   
   public boolean search(Object key)
   {
      if( isEmpty() )
         return false;
         
      if( head.data.toString().equals(key.toString()))
         return true;
         
      if( tail.data.toString().equals(key.toString()))
         return true;
         
      MyNode temp = head;
      while(temp.next != null)
      {
         if(temp.data.toString().equals(key.toString()))
         {
            return true; //found somewhere in the middle of the nodelist
         }
         temp = temp.next;
      }
      
      return false; //the loop ends, yet it was not found
         
   }
   
   public boolean add(Object item)
   {
      if( isFull() )
         return false;
         
      MyNode node = new MyNode(item); //create the node
      
      if( isEmpty() )
      {
         head = node;
         tail = node;
      } 
      else 
      {
         //not isempty anymore
         tail.next = node;
         tail = node;
      }

      count = count + 1;
      return true;
   }
   
   public boolean removeByHead()
   {
      if( isEmpty() )
         return false;
         
      if( head.next == null )
         head = null;
      else
      {
         head = head.next;
      }
      count = count - 1;
      return true;
   }
   
   public boolean removeByTail()
   {
      if( isEmpty() )
         return false;
         
      if(head != null && tail != null && head == tail)
      {
         head = null;
         tail = null;
      }
      else 
      {
         MyNode temp = head;
         while(temp.next != tail)
         {
            temp = temp.next;
         }
         
         tail = temp;
         tail.next = null;
         
      }
      
      count = count - 1;
      return true;
   }
   
   public String toString()
   {
      String result = "";
      if(!isEmpty())
      {
         MyNode temp = head;
         while(temp != null)
         {
            result += "[" + temp.data.toString() + "]->";
            temp = temp.next;
         }
         result += "\n";
         result += "Head: " + head.data.toString() + "\n";
         result += "Tail: " + tail.data.toString() + "\n";
      }
      
      return result;
   }
   
   public static void main(String[] args)
   {
      MyNodeList list = new MyNodeList();
      list.add("1");
      list.add("5");
      list.add("2");
      System.out.println(list.toString());
      list.removeByTail();
      System.out.println(list.toString());
      list.removeByTail();
      System.out.println(list.toString());
   }
   
}