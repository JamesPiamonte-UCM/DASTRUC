public class QueueArray 
{
   Object[] items;
   int count;
   
   public QueueArray()
   {
      items = new Object[10];
      count = 0;
   }
   
   public boolean isEmpty()
   {
      return count == 0;
   }
   
   public boolean isFull()
   {
      return count == items.length;
   }
   
   public boolean enqueue(Object newItem)
   {
      if(!isFull())
      {
         items[count] = newItem;
         count = count + 1;
         return true;
      }
      return false;
   }
   
   public boolean dequeue()
   {
      if(!isEmpty())
      {
         for(int i=0; i<count-1; i++)
         {
            items[i] = items[i + 1];
         }
         
         items[count-1] = null;
         count = count - 1;
         return true;
      }
      
      return false;
   }
   
   public String toString()
   {
      String result = "";
      if(!isEmpty())
      {
         for(int i=0; i<count; i++)
         {
            result += "[" + items[i]  + "]->";
         }      
      }
      
      return result;
   }
   
   public static void main(String[] args)
   {
      QueueArray qa = new QueueArray();
      qa.enqueue("A");
      qa.enqueue("B");
      qa.enqueue("C");
      System.out.println(qa);
      qa.dequeue();
      System.out.println(qa);
      qa.dequeue();
      System.out.println(qa);
      
   }
}