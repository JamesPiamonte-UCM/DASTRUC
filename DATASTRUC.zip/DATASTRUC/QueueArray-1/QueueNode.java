public class QueueNode
{
   MyNode head;
   MyNode tail;
   int count;
   
   public QueueNode()
   {
      head = null;
      tail = null;
      count = 0;
   }
   
   public boolean isEmpty()
   {
      return head == null && tail == null;
   }
   
   public boolean isFull()
   {
      return false;
   }
   
   public boolean enqueue(Object newItem)
   {
      MyNode newNode = new MyNode(newItem);
      if(isEmpty())
      {
         head = newNode;
         tail = newNode;
      }
      else 
      {
         tail.next = newNode;
         tail = newNode;
      }
      count = count + 1;
      return true;
   }
   
   public boolean dequeue()
   {
      if(!isEmpty())
      {
         if(head == tail)
         {
            head = null;
            tail = null;
         }
         else 
         {
            head = head.next;
         }
      }
      count = count - 1;
      return true;
   }
   
   public String toString()
   {
      String result = "";
      if(!isEmpty())
      {
         MyNode temp = head;
         while(temp != null)
         {
            result += "[" + temp.data + "]->";
         }
      }
      
      return result;
   }
   
   public static void main(String[] args)
   {
      QueueNode qn = new QueueNode();
      qn.enqueue(5);
      qn.enqueue(8);
      qn.enqueue(7);
      qn.enqueue(0);
      System.out.println(qn);
   }
}