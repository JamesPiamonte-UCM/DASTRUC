public class MyStackNode
{
   MyNode head;
   MyNode tail;
   int count;
   
   public MyStackNode()
   {
      this.head = null;
      this.tail = null;
      this.count = 0;
   }
   
   public boolean isEmpty()
   {
      return head == null && tail == null;
   }
   
   public boolean isFull()
   {
      return false;
   }
   
   public boolean push(Object newItem)
   {
      MyNode newNode = new MyNode(newItem);
      if(isEmpty())
      {
         head = newNode;
         tail = newNode;
      }
      else 
      {
         tail.next = newNode;
         tail = newNode;
      }
      count = count + 1;
      return true;
   }
   
   public Object peek()
   {
      if(!isEmpty())
      {
         return tail.data;
      }
      return null;
   }
   
   public boolean pop()
   {
      if(!isEmpty())
      {
         if(head == tail)
         {
            head = null;
            tail = null;
         }
         else 
         {
            MyNode temp = head;
            while(temp.next !=  tail)
            {
               temp = temp.next;
            }
            
            temp.next = null;
            tail = temp;
         }
         count = count - 1;
         return true;
      }
      
      return false;
      
   }
   
   public String toString()
   {
      String result = "";
      if(!isEmpty())
      {
         MyNode temp = head;
         while(temp != null)
         {
            result += "[" + temp.data + "]->";
            temp = temp.next;
         }
      }
      return result;
   }
   
   public static void main(String[] args)
   {
      MyStackNode msn = new MyStackNode();
      msn.push("Java");
      msn.push("CCS");
      msn.push("Java");
      msn.push("Python");
      msn.push("C");
      msn.push("C++");
      System.out.println(msn);
      msn.pop();
      System.out.println(msn);
      msn.pop();
      System.out.println(msn);
      System.out.println("Peek: " + msn.peek().toString());
   }
   
}