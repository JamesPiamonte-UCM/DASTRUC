public class MyStackArray
{
   Object[] items;
   int count;
   
   public MyStackArray()
   {
      items = new Object[10];
      count = 0;
   }
   
   public boolean isEmpty()
   {
      return count == 0;
   }
   
   public boolean isFull()
   {
      return count == items.length;
   }
   
   public boolean push(Object newItem)
   {
      if(!isFull())
      {
         items[count] = newItem;
         count = count + 1;
         return true;
      }
      return false;
   }
   
   public Object peek()
   {
      if(! isEmpty())
      {
         return items[count-1];
      }
      return null;
   }
   
   public boolean pop()
   {
      if(!isEmpty())
      {
         items[count-1] = null;
         count = count - 1;
         return true;
      }
      
      return false;
   }
   
   public String toString()
   {
      String result = "";
      if(!isEmpty())
      {
         result += "[";
         for(int i=0; i<count; i++)
         {
            result += items[i];
            if(i<count-1)
            {
               result += ", ";
            }
         }
         result += "]";
      }
      
      return result;
      
   }
   
   public static void main(String[] args)
   {
      MyStackArray msa = new MyStackArray();
      msa.push("CCS");
      msa.push("Java");
      msa.push("Python");
      msa.push("C");
      msa.push("C++");
      System.out.println(msa);
      msa.pop();
      System.out.println(msa);
      msa.pop();
      System.out.println(msa);
      System.out.println("Peek: " + msa.peek().toString());
   }
}