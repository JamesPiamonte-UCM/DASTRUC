import java.util.*;
import javax.swing.JOptionPane;


public class MyArrayList 
{
   private Object[] items;
   private int count;
   
   public MyArrayList(int size)
   {
      if(size <= 1)
         size = 10;
      
      items = new Object[size];
   }
   
   public MyArrayList()
   {
      items = new Object[10];
   }
   
   public boolean isEmpty()
   {
      if(count == 0)
         return true;
      else
         return false;
   }
   
   public boolean isFull()
   {
      if(count == items.length)
         return true;
      else
         return false;
   }
   
   public int search(Object findItem)
   {
      if( ! isEmpty() )
      {
         for(int i=0; i<count; i++)
         {
            if(items[i].toString().equals(findItem))
            {
               return i;
            }
         }
      }
      
      return -1;
   }
   
   public boolean add(Object addItem)
   {
      if( ! isFull() )
      {
      
         //search first the item that you want to add
         // if it is existing, nevermind
         // if not, add it
         
         int location = search(addItem);
         if(location == -1) //it means, it does not exist
         {
            //then proceed to add
            items[count] = addItem;
            count = count + 1;
            return true;
         }
      
      }
      return false;
   }
   
   public boolean update(int location, Object newItem)
   {
      if( ! isEmpty() )
      {
      
         //check if the location is within the range or boundary
         if(location >= 0 && location <= count-1)
         {
            items[location] = newItem;
            return true;
         }
      }
      
      return false;
   }
   
   public boolean update(Object oldItem, Object newItem)
   {
      if( ! isEmpty() )
      {
         int location = search(oldItem);
         
         if(location != -1) //meaning the oldItem exists
         {
            items[location] = newItem;
            return true;
         }
      }
      
      return false;
   }
   
   public boolean remove(int location)
   {
      if( ! isEmpty() )
      {
         if(location >= 0 && location <= count-1)
         {
            items[location] = items[count-1];
            items[count-1] = null; //delete the last item inserted
            count = count - 1;
            return true;
         }
      }
      
      return false;
   }
   
   public boolean remove(Object removeItem)
   {
      if( ! isEmpty() )
      {
         int location = search(removeItem);
         if(location != -1) //not equal to -1, meaning it exists
         {
            items[location] = items[count-1];
            items[count-1] = null; //totally remove it
            count = count - 1;
            return true;
         }
      }
      
      return false;
   }
   
   public boolean removeVersion2(int location)
   {
      if( ! isEmpty() )
      {
         if(location >= 0 && location <= count-1)
         {
            items[location] = null;
            if(count == 1)
            {
               count = count - 1;
            }
            else 
            {
               for(int i=location; i<=count-1; i++)
               {
                  //shift the elements
                  items[i] = items[i+1];
               }
               //to avoid duplicating the last item
               //set it to null
               items[count-1] = null;
               count = count - 1;
            }
            return true;
            
            
         }
      }
      return false;
   }
   
   /*
   public String toString()
   {
      if( ! isEmpty() )
      {
         String result = "";
         for(int i=0; i<count; i++)
         {
            result += "[" + items[i] + "] => " + i + "\n";
         }
         return result;
      }
      
      return "No items found in the array list.";
   }
   */
   
   public String toString()
   {
      if( ! isEmpty())
      {
         String result = "[";
         for(int i=0; i<count; i++)
         {
            result += items[i];
            if(i < count-1) //if it has not yet reached the last element
            {
               result += ", "; //then you add comma and space
            }
            
         }
         result += "]";
         return result;
      }
      
      return "No items found in the array list.";
   }
   
      
   public static void main(String[] args)
   {
       Scanner sc = new Scanner(System.in);
   
       System.out.print("Enter the size of the array list: ");
       int size = sc.nextInt();
   
       MyArrayList list = new MyArrayList(size);
   
       int choice = 0;
   
       while(true)
       {
           System.out.println("\n=== MyArrayList ===");
           System.out.println("1. Add Item");
           System.out.println("2. Display Items");
           System.out.println("3. Remove Item using Location");
           System.out.println("4. Remove Item using Item Value");
           System.out.println("5. Update Item using Location");
           System.out.println("6. Update Item using Item Value");
           System.out.println("7. Get Item Data");
           System.out.println("8. Clear The ArrayList");
           System.out.println("9. Search Item by Item Value");
           System.out.println("10. Exit Program");
   
           System.out.print("Enter choice: ");
           choice = sc.nextInt();
           sc.nextLine();
   
           if(choice == 1)
           {
               String item = JOptionPane.showInputDialog("Enter item:");
               if(list.add(item))
                   JOptionPane.showMessageDialog(null, "Added!");
               else
                   JOptionPane.showMessageDialog(null, "Cannot add (duplicate/full).");
           }
   
           else if(choice == 2)
           {
               JOptionPane.showMessageDialog(null, list.toString());
           }
   
           else if(choice == 3)
           {
               int loc = Integer.parseInt(JOptionPane.showInputDialog("Enter location:"));
               if(list.remove(loc))
                   JOptionPane.showMessageDialog(null, "Removed!");
               else
                   JOptionPane.showMessageDialog(null, "Invalid location.");
           }
   
           else if(choice == 4)
           {
               String item = JOptionPane.showInputDialog("Enter item:");
               if(list.remove(item))
                   JOptionPane.showMessageDialog(null, "Removed!");
               else
                   JOptionPane.showMessageDialog(null, "Item not found.");
           }
   
           else if(choice == 5)
           {
               int loc = Integer.parseInt(JOptionPane.showInputDialog("Enter location:"));
               String newItem = JOptionPane.showInputDialog("Enter new value:");
               if(list.update(loc, newItem))
                   JOptionPane.showMessageDialog(null, "Updated!");
               else
                   JOptionPane.showMessageDialog(null, "Invalid location.");
           }
   
           else if(choice == 6)
           {
               String oldItem = JOptionPane.showInputDialog("Enter old value:");
               String newItem = JOptionPane.showInputDialog("Enter new value:");
               if(list.update(oldItem, newItem))
                   JOptionPane.showMessageDialog(null, "Updated!");
               else
                   JOptionPane.showMessageDialog(null, "Item not found.");
           }
   
           else if(choice == 7)
           {
               int loc = Integer.parseInt(JOptionPane.showInputDialog("Enter location:"));
               if(loc >= 0 && loc < list.count)
                   JOptionPane.showMessageDialog(null, "Item: " + list.items[loc]);
               else
                   JOptionPane.showMessageDialog(null, "Invalid location.");
           }
   
           else if(choice == 8)
           {
               list = new MyArrayList(size);
               JOptionPane.showMessageDialog(null, "List cleared.");
           }
   
           else if(choice == 9)
           {
               String item = JOptionPane.showInputDialog("Enter item:");
               int index = list.search(item);
               if(index != -1)
                   JOptionPane.showMessageDialog(null, "Found at index: " + index);
               else
                   JOptionPane.showMessageDialog(null, "Not found.");
           }
   
           else if(choice == 10)
           {
               int confirm = JOptionPane.showConfirmDialog(null,
               "Are you sure you want to exit?",
               "Exit Confirmation",
               JOptionPane.YES_NO_OPTION);
         
               if(confirm == JOptionPane.YES_OPTION)
               {
                 JOptionPane.showMessageDialog(null, "Program ended.");
               }
               else
               {
                   choice = 0; // go back to menu
               }
           }
           System.out.println("\nPress any key to continue...");
           sc.nextLine();
       }
   
   }   
}