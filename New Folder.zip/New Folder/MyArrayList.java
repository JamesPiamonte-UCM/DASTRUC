public class MyArrayList {

   private String[] elements;
   private int counter;
   
   public MyArrayList(int size){
      elements = new String[size];
      counter = 0;
   }
   
   public boolean isEmpty(){
   
      if(counter == 0)
         return true;
      else
         return false;
   }
   
   public boolean isFull(){
      
      if (counter == elements.length)
         return true; //full already
      else
         return false; //not yet full
   }
   
   public int search (String find){
   
      if ( isEmpty())
         return - 1;
      else {
         for (int i=0; i<counter; i++){
            if (elements[i].equals(find)){
               return i; //return location/INDEX
            }
         }
         return -1;
      }
   }
   
   public boolean add (String item){
      
      if (isFull())
         return false; //cannot add anymore
      else {
         elements [counter] = item;
         counter = counter + 1;
         return true; //no error successfully added
      }
   }
   
   public boolean remove(int location){
      
      if(! isEmpty()){
         if(location >=0 && location <= counter - 1){
            //proceed to removal
            elements[location] = elements[counter - 1];
            elements[counter - 1] = ' ';
            counter = counter - 1;
            return true;
         }
      }
      return false;
   }
   
   
}