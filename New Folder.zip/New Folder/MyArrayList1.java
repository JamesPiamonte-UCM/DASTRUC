public class MyArrayList1 {

    private String[] elements;
    private int counter;

    public MyArrayList1(int size){
        elements = new String[size];
        counter = 0;
    }

    public boolean isEmpty(){
        return counter == 0;
    }

    public boolean isFull(){
        return counter == elements.length;
    }

    public int search(String find){
        if(isEmpty())
            return -1;

        for(int i = 0; i < counter; i++){
            if(elements[i].equals(find)){
                return i;
            }
        }
        return -1;
    }

    public boolean add(String item){
        if(isFull())
            return false;

        elements[counter] = item;
        counter++;
        return true;
    }

    public boolean remove(int location){
        if(!isEmpty()){
            if(location >= 0 && location <= counter - 1){
                elements[location] = elements[counter - 1];
                elements[counter - 1] = null; // clear last element
                counter--;
                return true;
            }
        }
        return false;
    }
} // <-- closing brace for class