public class MyCharArrayList3 {

    private char[] arr;
    private int counter;

    // Constructor
    public MyCharArrayList3(int size){
        arr = new char[size];
        counter = 0;
    }

    // Check if empty
    public boolean isEmpty(){
        return counter == 0;
    }

    // Check if full
    public boolean isFull(){
        return counter == arr.length;
    }

    // Search for a character, returns index or -1 if not found
    public int search(char element){
        for(int i = 0; i < counter; i++){
            if(arr[i] == element){
                return i;
            }
        }
        return -1;
    }

    // Add a character
    public boolean add(char element){
        if(isFull())
            return false;

        arr[counter] = element;
        counter++;
        return true;
    }

    // Remove a character by value
    public boolean remove(char element){
        if(isEmpty()){
            System.out.println("Cannot remove: ArrayList is empty");
            return false;
        }

        int index = search(element);

        if(index == -1){
            System.out.println("Cannot remove: Element '" + element + "' does not exist");
            return false;
        }

        // Replace the removed element with the last element
        arr[index] = arr[counter - 1];
        arr[counter - 1] = ' '; // clear last element
        counter--;
        return true;
    }

    // Display the array
    public void display(){
        System.out.print("Array contents: ");
        for(int i = 0; i < arr.length; i++){
            System.out.print(arr[i] + " ");
        }
        System.out.println("\nCounter: " + counter);
    }

    // Demo
    public static void main(String[] args){
        MyCharArrayList3 list = new MyCharArrayList3(5);

        list.add('A');
        list.add('B');
        list.add('C');
        list.display();

        System.out.println("\nRemoving 'B'");
        list.remove('B');
        list.display();

        System.out.println("\nRemoving 'D' (does not exist)");
        list.remove('D');
        list.display();

        System.out.println("\nRemoving 'A'");
        list.remove('A');
        list.display();
    }
}